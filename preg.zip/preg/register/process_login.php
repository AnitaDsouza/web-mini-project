<?php session_start();

require('../includes/config.php');
	
	if(!empty($_POST))
	{
		$msg="";
		
		if(empty($_POST['email']))
		{
			$msg="No such User";
		}
		
		if(empty($_POST['pwd']))
		{
			$msg="Password Incorrect........";
		}
		
		
		if(!empty($msg))
		{
			echo '<b>Error:-</b><br>';
			
			foreach((array)$msg as $k)
			{
				echo '<li>'.$k;
			}
		}
		else
		{
			
			
	
			
			$email=$_POST['email'];
			
			$q="select * from user where u_gmail='$email'";
			
			$res=mysqli_query($conn,$q) or die("wrong query");
			
			$row=mysqli_fetch_assoc($res);
			
			if(!empty($row))
			{
				if($_POST['pwd']==$row['u_pwd'])
				{
					$_SESSION=array();
					$_SESSION['u_fnm']=$row['u_fnm'];
					$_SESSION['pwd']=$row['u_pwd'];
					$_SESSION['status']=true;
					
					header("location:../home.html");
				}
				
				else
				{
					echo 'Incorrect Password....';
				}
			}
			else
			{
				echo 'Invalid User';
			}
		}
	
	}
	else
	{
		header("location:index.php");
	}
			
?>