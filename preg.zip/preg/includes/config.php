<?php 
$conn=mysqli_connect("localhost","root","","preg")or die("Can't Connect...");
	
?>