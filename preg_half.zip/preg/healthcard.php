<html>

<head>

<?php

 include("includes/head.html");
 ?>

</head>
<body>

<?php

 include("includes/menu.html");
 ?>
 
<div id="content">
	
	
			<h4> About Health card </h4>
			<div id="row">
			<div id="col-2">
				  <div class="clearfix">
				  <div class="box" >
					<div class="img-container">
						<img src="images/tc.jpg" alt="thayicard" style="width:100%" >
					</div>
				  </div>
				  <div class="box" >
					<p>
							</br>thayi card-  government of karnataka </br>Comprehensive Mother and Child registration booklet.​​ </br>
							In line with Maternal and Child Protection Card guidelines from Government of India.</br>
							Used for disbursement of free entitlements like JSY, Prasuthi Araike as well as Madilu kits. </p>
				  </div>
				</div>
				</div>
							
			</div>
			<h4> AWW REGISTRATION </h4>
			<div id="row">
			<div class="col-2">
			<p>
			</br>A woman must register with the ANM and AWW
			within the first three months of the pregnancy.However, if a woman comes late in her pregnancy for
			registration, she should not be denied registration and
			must be registered, and care given to her according to
			the gestational age (duration of pregnancy).
			</br>The ANM/AWW must explain the significance and
			relevance of all the headings in the Mother and Child
			Protection Card and encourage the woman and/or
			family members to ask questions and explain what is
			not clear
			 </p>
			</div>
			</div>
</div>

<?php

 include("includes/footer.html");
 ?>
 
 </body>
 </html>