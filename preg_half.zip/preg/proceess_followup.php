<?php
 session_start();
 extract($_POST);
 extract($_SESSION);
 
require('includes/config.php'); 	
	//echo $uid;
	if(isset($submit))
	{
	$query="insert into appointment (u_id , a_date , a_time) values('$product_name','$qty','$o_usn')";
	
	$res=mysqli_query($conn,$query) or die("Can't Execute Query...");
	
	}


?>
