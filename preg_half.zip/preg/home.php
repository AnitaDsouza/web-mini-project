<html>
<head>
<style>
.main {   
    flex: 70%;
    background-color: white;
    padding: 50px;
}

.home-container{
	
    padding: 10px;
	background: url(images/a1.jpg);
	background-repeat: no-repeat;
    background-size: cover;
}
</style>
</head>
<body>
<?php
	include("includes/menu.html");
?>

 <div class="main">
     
</div>

<div class="home-container">
<h2>welcome to Pregcare</h2>
<p>Your online Nanny</p>

<?php
	include("includes/slideshow.html");
?>


</div>

<?php
	include("includes/footer.html");
?>
</body>
</html>
