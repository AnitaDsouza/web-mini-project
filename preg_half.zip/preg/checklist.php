<html>

<head>

<?php

 include("includes/head.html");
 ?>

</head>
<body>

<?php

 include("includes/menu.html");
 ?>
 
<div id="infocontent">
	
	<div class="img-container-info">
						<img src="images/checklist.jpg" alt="thayicard" style="width:100%">
	</div>
</div>

<?php

 include("includes/footer.html");
 ?>
 
 </body>
 </html>