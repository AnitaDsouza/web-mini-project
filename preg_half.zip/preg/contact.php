<!DOCTYPE html>
<html>
<head>
<?php

 include("includes/head.html");
 ?>
 
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
    width: 50%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    margin-top: 6px;
    margin-bottom: 16px;
    resize: vertical;
}

input[type=submit] {
    background-color: #4CAF50;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}

.container {
	margin: 0 auto;
	width:50%;
    border-radius: 5px;
    background-color: white;
    padding: 40px;
}
</style>
</head>
<body>

<?php

 include("includes/menu.html");
 ?>
 

<h3 >Contact Form</h3>

<div class="container">
  <form action="process_contact.php">
    <label for="fname">First Name</label>
    <input type="text" id="fname" name="firstname" placeholder="Your name.."></br>

    <label for="lname">Last Name</label>
    <input type="text" id="lname" name="lastname" placeholder="Your last name.."></br>

    

    <label for="subject">Subject</label></br>
    <textarea id="subject" name="subject" placeholder="Write something.." style="height:200px"></textarea></br>

    <input type="submit" value="Submit">
  </form>
</div>


<?php

 include("includes/footer.html");
 ?>
</body>
</html>
