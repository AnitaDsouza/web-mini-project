<?php session_start(); ?>

<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="signup.css" rel="stylesheet" type="text/css" />
</head>
<body>

<!-- PAGE CONTENT -->
			<div class="bg">
				<div id="reg">
				
				<?php
						if(isset($_GET['error']))
						{
							echo '<font color="red">'.$_GET['error'].'</font>';
							echo '<br><br>';
						}
											
						if(isset($_GET['ok']))
						{
							echo '<font color="blue">You are successfully Registered..</font>';
							echo '<br><br>';
						}
										
				?>
									
				
				
					<form action="process_register.php" method="POST">
					  <div class="container">
							<h1>welcome to pregcare</h1>
							<p>Please fill in this form to create an account.</p>
							<hr>
							
							<label for="fnm"><b>first name</b></label>
							<input type="text" placeholder="Enter first name " name="fnm" required> 
							
							<label for="lnm"><b>last name</b></label>
							<input type="text" placeholder="Enter last name" name="lnm" required> <br/>

							<label for="email"><b>Gmail</b></label>
							<input type="email" placeholder="Enter Email" name="email" required> <br/>

							<label for="psw"><b>Password</b></label>
							<input type="password" placeholder="Enter Password" name="pwd" required> <br/>

							<label for="psw-repeat"><b>Repeat Password</b></label>
							<input type="password" placeholder="Repeat Password" name="cpwd" required> <br/>
							
							<label for="duedate"><b>Due Date:</b></label>
							<input type="date" placeholder="enter the due date" name="duedate" required> <br/>
							
							<label for="phone"><b>Contact:</b></label>
							<input type="phone" placeholder="enter mobile number" name="contact" required> <br/>
							<hr>
							
							<button type="submit" class="registerbtn">Register</button>
						  </div>
						  
						  <div class="container signin">
							<p>Already have an account? <a href="login.php">Sign in</a>.</p>
						  </div>
					</form>
				</div>
			</div>
</body>
</html>
