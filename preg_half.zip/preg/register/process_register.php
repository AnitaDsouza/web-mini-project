<?php
	require('../includes/config.php');
	
	if(!empty($_POST))
	{
		$msg="";
		
		if(empty($_POST['fnm']) || empty($_POST['lnm']) ||empty($_POST['pwd']) || empty($_POST['cpwd']) || empty($_POST['duedate']) || empty($_POST['email'])|| empty($_POST['contact']))
		{
			$msg.="<li>Please full fill all requirement";
		}
		
		if($msg!="")
		{
			header("location:register.php?error=".$msg);
		}
		else
		{
			$fnm=$_POST['fnm'];
			$lnm=$_POST['lnm'];
			$email=$_POST['email'];
			$pwd=$_POST['pwd'];
			//$duedate=POST['duedate'];
			$contact=$_POST['contact'];
			
			
				$due_date=strtotime($_POST['duedate']);
				$date=date('c', $due_date);
								
			$query="insert into user(u_fnm,u_lnm,u_gmail,u_pwd,u_duedate,u_contact)
			values('$fnm','$lnm','$email','$pwd','$date','$contact')";
			
			mysqli_query($conn,$query) or die("Can't Execute Query...");
			header("location:register.php?ok=1");
		}
	}
	else
	{
		header("location:index.html");
	}
?>