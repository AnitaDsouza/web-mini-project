<html>

<head>

<?php

 include("includes/head.html");
 ?>

</head>
<body>

<?php

 include("includes/menu.html");
 ?>
 
<div id="followcontent">
	
	
			<h2> Follow Up </h2>
			
			
				<form action="process_followup.php" method='POST'>
				<table >
					<tr><th>
						APPOINTMENT DETAILS:
					</th></tr>
					<tr>
						 <td>  <label for="movie">appointment number : </label><input id="appno"   type="number" value="0"/></td>
						 <td>   <label for="meeting">first appointment Date : </label><input id="date" type="date" value="2018-01-13"/></td>
						 <td>   <label for="meeting">first appointment time : </label><input id="time" type="time" value="00:00"/></td>			
			        </tr>
			
					<th>
					<h4>Test Details</h4>
					
					<p>Have You taken tests yet !? </p></th>
	
			<tr>
			<td><label>Down Syndrome test : </label><input name="down" type="radio" />Yes<input name="down" type="radio" />no<br></td>
			<td><label>Double Marker test : </label><input name="dot" type="radio" />Yes<input name="dot" type="radio" />no<br></td>
			</tr>
			
			
			<tr>
			<td><label>cvs test : </label><input name="cvs" type="radio" />Yes<input name="cvs" type="radio" />no<br></td>
			<td><label>HIV : </label><input name="hiv" type="radio" />Yes<input name="hiv" type="radio" />no<br></td>
			</tr>
			
			
			<tr>
			<td><label>hepatitis test : </label><input name="hepatitis" type="radio" />Yes<input name="hepatitis" type="radio" />no<br></td>
			<td><label>diabetics test : </label><input name="diab" type="radio" />Yes<input name="diab" type="radio" />no<br></td>
			</tr>
			
			
			</table>
			</form>
</div>

<?php

 include("includes/footer.html");
 ?>
 
 </body>
 </html>